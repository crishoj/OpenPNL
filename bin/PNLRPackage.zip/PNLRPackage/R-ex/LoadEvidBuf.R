### Name: LoadEvidBuf
### Title: Loads evidence buffer content from file
### Aliases: LoadEvidBuf
### Keywords: LoadEvidBuf

### ** Examples

##Load evidences from file "evidence1.csv" with ',' separators and perform learning with them: 

LoadEvidBuf(net, "evidence1.csv")
LearnParameters(net) 




