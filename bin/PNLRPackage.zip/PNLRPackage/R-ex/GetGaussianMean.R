### Name: GetGaussianMean
### Title: Returns mean of gaussian distribution
### Aliases: GetGaussianMean
### Keywords: GetGaussianMean

### ** Examples

MeanX2 <- GetGaussianMean(net, "x2") 



