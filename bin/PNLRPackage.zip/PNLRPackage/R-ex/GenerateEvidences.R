### Name: GenerateEvidences
### Title: Generate samples for the network
### Aliases: GenerateEvidences
### Keywords: GenerateEvidences

### ** Examples

##Generate 100 samples for all network nodes ignoring current evidence: 

GenerateEvidences(net,  100, true) 

##Generate 100 samples only for nodes "NodeA","NodeB" and "NodeC" using current evidence: 

GenerateEvidences(net, 100, false, "NodeA NodeB NodeC") 

##Generate 100 samples only for nodes "NodeA","NodeB" and "NodeC" using current evidence. "NodeA" should contain 90

GenerateEvidences(net, 100, false, "NodeA^0.9 NodeB^1.0 NodeC^1.0") 

##Generate 100 samples for nodes "NodeA","NodeB" and "NodeC" using current evidence. All nodes should contain 90

GenerateEvidences(net, 100, false, "NodeA^0.9 NodeB^0.9 NodeC^0.9 ") 

##Generate 100 samples for all nodes using current evidence. All nodes should contain 90

GenerateEvidences(net, 100, false, whatNodesToSample, "0.9") 



