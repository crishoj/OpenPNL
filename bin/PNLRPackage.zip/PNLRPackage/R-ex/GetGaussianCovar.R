### Name: GetGaussianCovar
### Title: Returns variance of gaussian distribution
### Aliases: GetGaussianCovar
### Keywords: GetGaussianCovar

### ** Examples

CovarX2 <- GetGaussianCovar(net, "x2") 



