### Name: ClearEvid
### Title: Clears current evidence
### Aliases: ClearEvid
### Keywords: ClearEvid

### ** Examples

EditEvidence(net, "NodeA^true NodeB^false")
ClearEvid(net) 

##Current evidence is empty now.



