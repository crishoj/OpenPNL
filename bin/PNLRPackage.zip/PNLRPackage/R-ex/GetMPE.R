### Name: GetMPE
### Title: Returns MPE
### Aliases: GetMPE
### Keywords: GetMPE

### ** Examples

##Get MPE for node "NodeA" with Junction Tree inference: 

SetProperty(net, "Inference", "jtree")
jtreeMPENodeA <- GetMPE(net, "NodeA") 

##Get MPE for nodes "NodeA" and "NodeB" with Pearl inference 
##(nodes "NodeA" and "NodeB" must be from the same family): 

SetProperty(net, "Inference", "pearl")
pearlMPENodeA <- GetMPE(net, "NodeA NodeB") 



