### Name: SaveEvidBuf
### Title: Saves evidence buffer content to file
### Aliases: SaveEvidBuf
### Keywords: SaveEvidBuf

### ** Examples

##Save two evidences to file with ',' separator: 

ClearEvidBuf(net)
AddEvidToBuf(net, "NodeA^true NodeB^false")
AddEvidToBuf(net, "NodeA^false NodeC^true")
SaveEvidBuf(net, "evidence1.csv") 




