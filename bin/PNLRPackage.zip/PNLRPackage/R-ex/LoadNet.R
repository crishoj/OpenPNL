### Name: LoadNet
### Title: Loads network from file
### Aliases: LoadNet
### Keywords: LoadNet

### ** Examples

##Load net structure and distributions from file "net.xml": 

LoadNet(net, "net.xml") 



