### Name: GetEMLearningCriterionValue
### Title: Returns criterion value for last EM learning execution
### Aliases: GetEMLearningCriterionValue
### Keywords: GetEMLearningCriterionValue

### ** Examples

SetProperty(net, "Learning", "em")
LearnParameters(net)
resLogLik <- GetEMLearningCriterionValue(net)




