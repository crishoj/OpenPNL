### Name: EditEvidence
### Title: Edits current evidence
### Aliases: EditEvidence
### Keywords: EditEvidence

### ** Examples

EditEvidence(net, "NodeA^true NodeB^false")
EditEvidence(net, "NodeA^false NodeC^true") 

##In current evidence there are three observed tabular nodes: "NodeA", "NodeB" 
##(both are false) and "NodeC"(true). 

EditEvidence(net, "ContNodeA^dim1^-15.0 ContNodeA^dim2^6.4")
EditEvidence(net, "ContNodeB^dim1^5.0") 

##In current evidence there are two observed continuous nodes: 
##"NodeA" (with 2 dimensions), "NodeB" (with one dimension). 



