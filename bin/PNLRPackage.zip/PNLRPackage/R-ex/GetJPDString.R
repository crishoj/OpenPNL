### Name: GetJPDString
### Title: Returns JPD as string
### Aliases: GetJPDString
### Keywords: GetJPDString

### ** Examples

##Get JPD for node "NodeA" with Junction Tree inference: 

SetProperty(net, "Inference", "jtree")
jtreeJPDNodeAStr <- GetJPDString(net, "NodeA") 

##Get JPD for nodes "NodeA" and "NodeB" with Pearl inference 
##(nodes "NodeA" and "NodeB" must be from the same family): 

SetProperty(net, "Inference", "pearl")
pearlJPDNodeAStr <- GetJPDString(net, "NodeA NodeB") 



