### Name: GetGaussianWeights
### Title: Returns weights of gaussian distribution.
### Aliases: GetGaussianWeights
### Keywords: GetGaussianWeights

### ** Examples

WeightsYX2 <- GetGaussianWeights(net, "y", "x2") 



