### Name: GetPTabularString
### Title: Returns probability of discrete node as one string
### Aliases: GetPTabularString
### Keywords: GetPTabularString

### ** Examples

##Let's consider getting of probabilities for node "NodeB" from example for SetPTabular method. 
##Some variants to get "NodeB" probabilites are available: 

PNodeB <- GetPTabularString(net, "NodeB")
PNodeBTrue <- GetPTabularString(net, "NodeB^true")
PNodeBNodeATrue <- GetPTabularString(net, "NodeB", "NodeA^true")
PNodeBTrueNodeAFalse <- GetPTabularString("NodeB^true", "NodeA^false") 

## Results of these calls: 

PNodeB
NodeB^true^NodeA^true^0.99 NodeB^false^NodeA^true^0.01 NodeB^true^NodeA^false^0.4 NodeB^false^NodeA^false^0.6"

PNodeBTrue
"NodeB^true^NodeA^true^0.99 NodeB^true^NodeA^false^0.4"

PNodeBNodeATrue
"NodeB^true^NodeA^true^0.99 NodeB^false^NodeA^true^0.01"

PNodeBTrueNodeAFalse
"NodeB^true^NodeA^false^0.4"



