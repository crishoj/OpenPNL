### Name: LearnStructure
### Title: Learns structure of the network
### Aliases: LearnStructure
### Keywords: LearnStructure

### ** Examples

AddEvidToBuf(net, "NodeA^true NodeB^false")
AddEvidToBuf(net, "NodeA^false NodeC^true")
LearnStructure(net) 



