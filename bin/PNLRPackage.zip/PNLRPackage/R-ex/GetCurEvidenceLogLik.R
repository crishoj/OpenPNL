### Name: GetCurEvidenceLogLik
### Title: Returns logarithm of likelihood for current evidence
### Aliases: GetCurEvidenceLogLik
### Keywords: GetCurEvidenceLogLik

### ** Examples

EditEvidence(net, "NodeA^true NodeB^false")
logLik <- GetCurEvidenceLogLik(net) 



