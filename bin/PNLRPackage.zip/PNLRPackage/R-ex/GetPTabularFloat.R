### Name: GetPTabularFloat
### Title: Returns probability of discrete node as float vector
### Aliases: GetPTabularFloat
### Keywords: GetPTabularFloat

### ** Examples

##Let's consider getting of probabilities for node "NodeB" from example for SetPTabular method. 
##Some variants to get "NodeB" probabilites are available: 

PNodeB <- GetPTabularString(net, "NodeB")
PNodeBTrue <- GetPTabularString(net, "NodeB^true")
PNodeBNodeATrue <- GetPTabularString(net, "NodeB", "NodeA^true")
PNodeBTrueNodeAFalse <- GetPTabularString("NodeB^true", "NodeA^false") 

## Results of these calls: 

PNodeB
0.99  0.01  0.4  0.6

PNodeBTrue
0.99  0.4

PNodeBNodeATrue
0.99  0.01

PNodeBTrueNodeAFalse
0.4



