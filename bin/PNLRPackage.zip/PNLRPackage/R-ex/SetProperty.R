### Name: SetProperty
### Title: Returns value of the property with given name
### Aliases: SetProperty
### Keywords: SetProperty

### ** Examples

SetProperty(net, "Inference", "pearl")
inferenceType <- GetProperty(net, "Inference")
learningType <- GetProperty(net, "Learning") 

##As result string inferenceType is "pearl" and string learningType is empty



