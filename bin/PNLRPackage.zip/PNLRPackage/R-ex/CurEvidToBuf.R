### Name: CurEvidToBuf
### Title: Stores current evidence to the evidence buffer
### Aliases: CurEvidToBuf
### Keywords: CurrEvidToBuf

### ** Examples

EditEvidence(net, "NodeA^true NodeB^false")
EditEvidence(net, "NodeA^false NodeC^true")
CurEvidToBuf(net)
EditEvidence(net, "NodeB^true")
CurEvidToBuf(net) 

##In current evidence there are three observed nodes now: "NodeA" takes on "false" value, 
##"NodeB" and "NodeC" take on "true" values. 

##In evidence buffer there are two evidences now. In first evidence "NodeA" and "NodeB" 
##take on "false" values, and "NodeC" takes on "true" value. In second one "NodeA" takes 
##on "false" value, "NodeB" and "NodeC" take on "true" values. 



