### Name: SetPGaussian
### Title: Sets parameters for gaussian variate
### Aliases: SetPGaussian
### Keywords: SetPGaussian

### ** Examples

##Let's set gaussian distribution for one - dimentional node without parents. 
SetPGaussian(net, "x0", "1.0", "4.0") 

##Let's set gaussian distribution for one - dimentional node with two parents. 
weightsX2 <- c(1.0, 2.0) 
SetPGaussian(net, "x2", "0.0", "2.0", weightsX2)

##Let's set gaussian distribution for two - dimensional node without parents. 
X0mean <- c(1.0, 2.5) 
X0variance <- c(4.0, 0.1, 0.1, 4.0) 
SetPGaussian(net, "x0", X0mean, X0variance) 

##Let's set gaussian distribution for two - dimentional node with three two - dimensional parents
SetPGaussian(net, "x2", "1.0 2.5", "4.0 0.1 0.1 4.0", "1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0") 




