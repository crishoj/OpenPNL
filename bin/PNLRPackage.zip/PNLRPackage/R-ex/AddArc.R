### Name: AddArc
### Title: Adds arcs
### Aliases: AddArc
### Keywords: AddArc

### ** Examples

## Add edge from node "NodeA" to node "NodeB"
AddArc(net, "NodeA", "NodeB")  
##Add two edges: from "NodeA" to "NodeB" and from "NodeA" to "NodeC"
AddArc(net, "NodeA", "NodeB NodeC") 
##Add four edges: from "NodeA" to "NodeC", from "NodeA" to "NodeD", from "NodeB" to "NodeC" and from "NodeB" to "NodeD"
AddArc(net, "NodeA NodeB", "NodeC NodeD") 




