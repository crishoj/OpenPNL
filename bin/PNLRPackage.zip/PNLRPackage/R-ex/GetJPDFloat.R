### Name: GetJPDFloat
### Title: Returns JPD as float vector
### Aliases: GetJPDFloat
### Keywords: GetJPDFloat

### ** Examples

##Get JPD for node "NodeA" with Junction Tree inference: 

SetProperty(net, "Inference", "jtree")
jtreeJPDNodeAFlt = GetJPDFloat(net, "NodeA") 

##Get JPD for nodes "NodeA" and "NodeB" with Pearl inference 
##(nodes "NodeA" and "NodeB" must be from the same family): 

SetProperty(net, "Inference", "pearl")
pearlJPDNodeAFlt = GetJPDFloat(net, "NodeA NodeB") 



