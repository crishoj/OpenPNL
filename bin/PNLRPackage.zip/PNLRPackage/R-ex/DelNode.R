### Name: DelNode
### Title: Deletes nodes
### Aliases: DelNode
### Keywords: DelNode

### ** Examples

## Delete nodes "NodeA" and "NodeB" from Bayessian net
DelNode(net, "NodeA NodeB")  



