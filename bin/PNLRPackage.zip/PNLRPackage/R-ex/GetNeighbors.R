### Name: GetNeighbors
### Title: Returns list of neighbours for given node as one string.
### Aliases: GetNeighbors
### Keywords: GetNeighbors

### ** Examples

##Get neighbors of node "NodeA"
NodeANeighbors <- GetNeighbours(net, "NodeA") 
##Get neighbors of node "NodeA" and neighbors of node "NodeB". If node "NodeC" is neighbor of both "NodeA" and "NodeB" then it is once in result list of neighbors
NodeAandBNeighbors <- GetNeighbours(net, "NodeA NodeB") 



