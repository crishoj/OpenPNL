### Name: ClearEvidBuf
### Title: Clears evidence buffer
### Aliases: ClearEvidBuf
### Keywords: ClearEvidBuf

### ** Examples

AddEvidToBuf(net, "NodeA^true NodeB^false")
AddEvidToBuf(net, "NodeA^false NodeC^true")
ClearEvidBuf(net) 

##Evidence buffer is empty now. 




