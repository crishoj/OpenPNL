### Name: SaveNet
### Title: Saves network to file
### Aliases: SaveNet
### Keywords: SaveNet

### ** Examples

SaveNet(net, "net.xml") 



