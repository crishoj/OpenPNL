### Name: MaskEvidBuf
### Title: Hides nodes of current learning buffer with given probability
### Aliases: MaskEvidBuf
### Keywords: MaskEvidBuf

### ** Examples

MaskEvidToBuf(net, "NodeA^true NodeB^false") 



