### Name: SetPTabular
### Title: Assigns probability to one or several values of one discrete
###   node
### Aliases: SetPTabular
### Keywords: SetPTabular

### ** Examples

##Let's assume that node "NodeA" has no parents and can take on two values: "true" and "false". 
##Its distribution of probabilities is unconditional. 

SetPTabular(net, "NodeA^true NodeA^false", "0.7 0.3") 

##Let's node "NodeB" can take on values "true" and "false" too and has only one parent "NodeA". 
##Distribution of probabilities of "NodeB" is conditional. It is necessary to call SetPTabular method 
##for each configuration of parents values

probB1 <- c(0.99, 0.01) 
probB2 <- c(0.4, 0.6) 
SetPTabular(net, "NodeB^true NodeB^false", probB1, "NodeA^true")
SetPTabular(net, "NodeB^true NodeB^false", probB2, "NodeA^false") 



