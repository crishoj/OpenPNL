### Name: GetNodeType
### Title: Returns types of the given nodes as strings
### Aliases: GetNodeType
### Keywords: GetNodeType

### ** Examples

##Get array of types of nodes "NodeA" and "NodeB": 
GetNodeType(net, "NodeA NodeB") 
##The output of this function call will be the following: "discrete" "discrete"



