### Name: LearnParameters
### Title: Learns network parameters
### Aliases: LearnParameters
### Keywords: LearnParameters

### ** Examples

AddEvidToBuf(net, "NodeA^true NodeB^false")
AddEvidToBuf(net, "NodeA^false NodeC^true")
LearnParameters(net) 



