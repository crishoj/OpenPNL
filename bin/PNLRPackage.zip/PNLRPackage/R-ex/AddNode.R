### Name: AddNode
### Title: Adds nodes
### Aliases: AddNode
### Keywords: AddNode

### ** Examples

## Add one discrete node "NodeA" with states "true" and "false" to bayes net
AddNode(net, "discrete^NodeA", "true false") 
##or 
AddNode(net, "NodeA", "true false") 
## Add one-dimensional continuous node "NodeA" to Bayessian net
AddNode(net, "continuous^NodeA", "dim1") 
## Add discrete nodes "NodeA" and "NodeB" with states "true" and "false" to bayes net
AddNode(net, "discrete^NodeA discrete^NodeB", "true false") 
## Add multivariate nodes "NodeA" with 2 dimensions "dim1" and "dim2" to bayes net
AddNode(net, "continuous^NodeA", "dim1 dim2") 



